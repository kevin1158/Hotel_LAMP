<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online Hotel Booking">
    <meta name="keywords" content="Cheap Hotels,Budget Hotels,Luxery Hotels">
    <meta name="creater" content="Schneizel">
    <title>Online Hotel Booking | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>



  <body>


   <header>
     <div class="container">
       <div id="branding">
         <h1><span class="highlight">Online</span> Hotel Booking</h1>
       </div>
       <nav>
         <ul>
           <li class="current"><a href="#">Home</a></li>
           <li><a href="about.html">About us</a></li>
           <li><a href="we.html">We Provide</a></li>
           <li><a href="Sign-up.php">Sign Up</a></li>
           <li><a href="login.php">login</a></li>
         </ul>
       </nav>
     </div>
   </header>
   <div class="container">
   <h2>Sign-Up Here</h2>

   <div class="container">
 	<h2>Sign-Up Here</h2>
<form action="" method="POST">
 			
 				<p>FIRST NAME</p>
				<input type="text" placeholder=" First Name" name="Fname" onkeyup="valFirstName();" autofill="off">
				<p>LAST NAME</p>
				<input type="text" placeholder="last Name" name="Lname" onkeyup="valLastName();" autofill="off">
				<p>USER-NAME</p>
				<input type="text" placeholder="USERNAME" name="user" required onkeyup="valUSERNAME();" autofill="off">
				<p>E-MAIL ADDRESS</p>
				<input type="E-MAIL" placeholder="EMAIL" name="email" required onkeyup="valEMAIL();" autofill="off">
				<p>PASSWORD</p>
				<input type="Password" placeholder="Password" name="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Alpha-numeric" required>
				
				<input type="submit" name="submit" value="Register">
				
			</form>
<?php
if(isset($_POST["submit"])){
 if(!empty($_POST['Fname']) && !empty($_POST['Lname'])&& !empty($_POST['user'])&& !empty($_POST['email'])&& !empty($_POST['pass']))
{
$Fname = $_POST['Fname'];
$Lname = $_POST['Lname'];
$user = $_POST['user'];
$email = $_POST['email'];
$pass = $_POST['pass'];
$conn = new mysqli('localhost', 'root', 'Kevin123') or die (mysqli_error()); // DB Connection
$db = mysqli_select_db($conn, 'project') or die("DB Error"); // Select DB from database
//Selecting Database
$numrows == 0;
if($numrows == 0)
{
//Insert to Mysqli Query
$sql = "INSERT INTO pro(Fname,Lname,user,email,pass) VALUES('$Fname','$Lname','$user','$email','$pass')";
$result = mysqli_query($conn, $sql);
//Result Message
if($result){
echo "Your Account Created Successfully";
}
else
{
echo "Failure!";
}
}
else
{
echo "That Username already exists! Please try again.";
}
}
else
{
?>
<!--Javascript Alert -->
<script>alert('Required all felds');</script>
<?php
}
}
?>
</body>
</html>
