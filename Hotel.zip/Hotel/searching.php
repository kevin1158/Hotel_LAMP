<!doctype html>
<html>
<head>
<title>Home</title>
<link rel="stylesheet"  href="signup.css">
</head>
<body>
<div>
<form action=" " method="post">

<input type="text" name="city" placeholder="Search by city">
<input type="submit" value="search">
<a href="logout.php">logout</a>

</form>
<?php
$m=mysqli_connect("localhost","root","Kevin123","project") or die("ERROR");
if ($_POST["city"]!=NULL){
$city=$_POST["city"];
$q="select * from hotel where city='$city'";
$res=mysqli_query($m,$q);
$r=mysqli_fetch_array($res);
if ($r[0]==NULL){
echo "No user found";
}
else{
echo "<p><h3>city : ".$r[5]."</h3></p>";
echo "<p><h3>hotel1 : ".$r[0]."</h3></p>";
echo "<p><h3>hotel2 : ".$r[1]."</h3></p>";
echo "<p><h3>hotel3 : ".$r[2]."</h3></p>";
echo "<p><h3>hotel4 : ".$r[3]."</h3></p>";
echo "<p><h3>hotel5 : ".$r[4]."</h3></p>";

}
}
?>
</div>
</body>
</html>
